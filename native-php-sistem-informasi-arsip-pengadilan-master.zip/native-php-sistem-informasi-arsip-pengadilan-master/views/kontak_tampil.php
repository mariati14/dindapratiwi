<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <h3 class="panel-title"><span class="fa fa-user-plus"></span> Kontak</h3>
                </div>
                <div class="panel-body">
                    <table id="dtskripsi" class="table table-bordered table-striped table-hover">
                        <thead>
                            <label class="col-sm-12 control-label"><center><strong>PENGADILAN NEGERI KISARAN</strong></center></label>
                            <p align="center">
                              Jalan Jendral Ahmad Yani No. 33, Sei Renggas, Kisaran, Sendang Sari, Kisaran Barat<br>
                              Kabupaten Asahan, Sumatera Utara, Kode Pos : 21211
                            </p>
                        </thead>
                        <tbody>
                          <div class="col-sm-2" align="center">

                          </div>
                          <div class="col-sm-8" align="center">
                            <br>
                            Telp. 12345678<br>
                            Email : pnkisaran@webmail.com<br>
                            Fax : 1234567<br>
                            Website : pnkisaran.go.id<br>
                            <br>
                          </div>
                          <div class="col-sm-2" align="center">
                          </div>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
