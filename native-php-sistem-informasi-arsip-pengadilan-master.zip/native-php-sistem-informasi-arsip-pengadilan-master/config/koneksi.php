<?php
// mysqli_connect("hostname","user database","password","nama")
$koneksi= mysqli_connect("localhost","root","","dbarsip") or die("Tidak bisa terhubungan ke database");


